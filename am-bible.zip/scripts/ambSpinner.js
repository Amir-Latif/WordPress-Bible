//#region Spinner Remover
window.addEventListener("load", () => {
    document.querySelector(".amb-spinner-container").remove();
  });
  //#endregion Spinner Remover