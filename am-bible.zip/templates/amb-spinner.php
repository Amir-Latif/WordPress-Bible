<div class="amb-spinner-container">
  <div class="amb-spinner">
    <div class="amb-bounce1"></div>
    <div class="amb-bounce2"></div>
    <div class="amb-bounce3"></div>
  </div>
</div>