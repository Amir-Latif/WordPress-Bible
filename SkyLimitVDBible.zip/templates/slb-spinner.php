<div class="slb-spinner-container">
  <div class="slb-spinner">
    <div class="slb-bounce1"></div>
    <div class="slb-bounce2"></div>
    <div class="slb-bounce3"></div>
  </div>
</div>